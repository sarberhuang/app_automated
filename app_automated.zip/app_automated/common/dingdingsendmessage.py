
import requests
import json
import base64
import hashlib
import hmac
import urllib.request
import time

def sendmessage(text):
    ##钉钉sha256签名

    timestamp = round(time.time() * 1000)

    secret = '自行填写'

    secret_enc = bytes(secret, encoding='UTF-8')

    string_to_sign = '{}\n{}'.format(timestamp, secret)

    string_to_sign_enc = bytes(string_to_sign, encoding='utf-8')

    hmac_code = hmac.new(secret_enc, string_to_sign_enc, digestmod=hashlib.sha256).digest()

    sign = urllib.request.quote(base64.b64encode(hmac_code))

    # 请求的URL，WebHook地址
    webhook = "自行填写&sign=%s&timestamp=%s" % \
              (sign, timestamp)


    header = {
        "Content-Type": "application/json",
        "Charset": "UTF-8"
    }
    # 构建请求数据
    message = {

        "msgtype": "text",
        "text": {
            "content": text
        },
        "at": {

            "isAtAll": False
        }

    }
    # 对请求的数据进行json封装
    message_json = json.dumps(message)
    # 发送请求
    info = requests.post(url=webhook, data=message_json, headers=header)
    # 打印返回的结果
    print(info.text)

