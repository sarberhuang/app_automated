#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
"""
import os
import time
import sys

from PIL import Image

from util import UIChecker, Common
from util.Adb import Adb
import config
from config import GlobalVar as GV
import platform
# from PIL import Image
from util import bugbuilder
from unittest import TestCase
import datetime
import subprocess


def now():
    """
    获取现在时间，格式%Y%m%d-%H%M%S
    :return:
    """
    return time.strftime("%Y%m%d-%H%M%S", time.localtime(time.time()))


def getNowTime():
    """
    获取现在时间，格式%Y-%m-%d %H:%M:%S
    :return:
    """
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))


def getNowTime_second():
    """获取现在时间，用来计算每个用例的运行时长"""
    return datetime.datetime.now()


def get_ten_timestamp():
    """获取当前10位时间戳"""
    datetime_object = datetime.datetime.now()
    now_timetuple = datetime_object.timetuple()
    now_second = time.mktime(now_timetuple)
    return now_second


def adb_cmd(cmd):
    """..."""
    if GV().device_id:
        x_cmd = "adb -s %s %s" % (GV().device_id, cmd[4:])
    else:
        x_cmd = cmd
    # config.logger.debug(x_cmd)
    os.system(x_cmd)


def adb_popen(cmd):
    """..."""
    if GV().device_id:
        x_cmd = "adb -s %s %s" % (GV().device_id, cmd[4:])
    else:
        x_cmd = cmd
    # config.logger.debug(x_cmd)
    r = os.popen(x_cmd)
    text = r.read()
    r.close()
    return text


def adb_subpopen(cmd):
    """..."""
    if GV().device_id:
        x_cmd = "adb -s %s %s" % (GV().device_id, cmd[4:])
    else:
        x_cmd = cmd
    # config.logger.debug(x_cmd)
    r = subprocess.getoutput(x_cmd)
    return r


def get_package_info_by_tag(package_name, tag="versionName"):
    """
    通过包名获取软件版本信息
    :param package_name:
    :param tag:
    :return:
    """
    tag_length = len(tag) + 1
    cmd = "adb shell dumpsys package %s | %s %s" % (package_name, GV().findstr, tag)
    print(cmd)
    version_str = adb_popen(cmd).strip()
    config.logger.info(version_str)

    version_start = version_str.find(tag) + tag_length
    if version_start < tag_length:
        config.logger.info("没有找到%s" % package_name)
        return -1
    else:
        info_name = version_str[version_start:]
        # import re
        # re_info = re.search(
        #     # "packageName=(?P<app_name>.*),.*"
        #     # "versionCode=(?P<version_code>.*) .*"
        #     "versionName=(?P<version>.*)\n.*",
        #     # "eventId=(?P<event>.*),.*"
        #     # "type=(?P<type>.*),.*"
        #     # "attach=(?P<attach>.*),.*"
        #     # "startTime=(?P<start>.*),.*"
        #     # "endTime=(?P<end>.*),.*"
        #     # "longitude=(?P<longitude>.*),.*",
        #     version_name,
        # )
        # event_dict = re_info.groupdict()
        config.logger.info("[packageName] %s" % (package_name))
        config.logger.info("[%s] %s" % (tag, info_name))
        return info_name


def killProcess(processname):
    """kill指定进程"""
    logcat_file = os.path.join(GV().LOG_ROOT, "%s_process.log" % processname)
    adb_cmd('adb shell ps -e | findstr "%s" > %s' % (processname, logcat_file))
    config.logger.info(processname)
    with open(logcat_file, 'r', encoding='utf-8') as f:
        pros = f.readlines()
    config.logger.error(pros)
    if len(pros) > 0:
        for s in pros:
            if s:
                process_id = s.split()[1]
                config.logger.error("kill %s: %s" % (processname, process_id))
                adb_popen("adb shell kill -9 %s" % process_id)


def exec_cmd(cmd):
    """
    执行系统命令的静态类方法
    :param cmd: 所要执行的命令
    :return: 终端输出
    """
    r = os.popen(cmd)
    text = r.read()
    r.close()
    return text


def creat_file(filename):
    """ 创建文件夹
    :param filename: 需要创建的文件路径
    :return:
    """
    if not os.path.exists("%s" % filename):
        os.makedirs("%s" % filename)
        config.logger.debug("creat file path :" + filename)


def screen_shot(file_path):
    """
    截图
    :param d: 设备号
    :param filepath: 地址
    :param times: 等待时间
    :return:
    """
    config.logger.debug("screencap time " + time.strftime("%Y%m%d%H%M%S"))
    adb_cmd("adb shell screencap -p /sdcard/test.png")
    adb_cmd("adb pull /sdcard/test.png %s" % file_path)
    config.logger.debug("screencap end time " + time.strftime("%Y%m%d%H%M%S"))


# 结束进程
def stop_process(d, process):
    """
    停止制定进程
    :param d: 设备号
    :param process: 进程名
    :return:
    """
    # 第一次尝试杀死( *・ω・)✄╰ひ╯
    result = exec_cmd("adb -s %s shell ps | %s %s" % (d, get_sys_commond(), process))
    # print("第一次尝试杀死: result=" + result)
    if result != "":
        list = result.split()
        num = len(list) / 9
        num = int(num)
        for i in range(0, num):
            process_id = list[i * 9 + 1]
            os.system("adb -s %s shell kill -9 %s" % (d, process_id))
    # 第一次杀不死时第二次尝试杀死( *・ω・)✄╰ひ╯
    result = exec_cmd("adb -s %s shell ps | %s %s" % (d, get_sys_commond(), process))
    if result != "":
        for index, v in enumerate(result.split('\n')):
            pidarray = v.split()
            if len(pidarray) > 1:
                # print(pidarray[1])
                os.system("adb -s %s shell kill %s" % (d, pidarray[1]))
    # 第二次杀不死时第三次尝试杀死( *・ω・)✄╰ひ╯
    result = exec_cmd("adb -s %s shell dumpsys cpuinfo | %s %s" % (d, get_sys_commond(), process))
    # print(result)
    if result != "":
        for index, v in enumerate(result.split('\n')):
            tmp = v.split()
            if len(tmp) > 1:
                # print(tmp[1])
                pidarray = tmp[1].split("/")
                if len(pidarray) > 1:
                    # print("第二次杀不死时第三次尝试杀死 pid=" + pidarray[0])
                    os.system("adb -s %s shell kill %s" % (d, pidarray[0]))
    # 第三次杀不死时第四次尝试杀死, 若仍杀不死可自行添加其他方法 (* ￣︿￣)
    result = exec_cmd("adb -s %s shell top -d 1 -n 2 -o PID,RES,SHR,%%CPU,%%MEM,ARGS -s 4 | %s %s" %
                      (d, get_sys_commond(), process))
    # print("第三次杀不死时第四次尝试杀死 result= " + result)
    if result != "":
        for index, v in enumerate(result.split('\n')):
            pidarray = v.split()
            if len(pidarray) > 1:
                # print("第三次杀不死时第四次尝试杀死 pid= " + pidarray[0])
                os.system("adb -s %s shell kill %s" % (d, pidarray[0]))


def get_sys_commond():
    """
    从系统获取管道指令类型
    :return: 管道指令
    """
    if 'Windows' in platform.system():
        return "findstr"
    else:
        return "findstr"


def clickByText(text):
    """匹配文本，点击"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    time.sleep(1)
    if UIChecker.checkByTextWait(text):
        config.logger.debug("找到%s" % text)
        d(text=text).click()
        error_code = 1
    else:
        config.logger.debug("没有找到%s" % text)
        error_code = 0
    time.sleep(1)
    return error_code


def longClickByText(text):
    """匹配文本，点击"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if UIChecker.checkByTextWait(text):
        d(text=text).long_click()
    time.sleep(1)


def longClickById(id):
    """匹配文本，点击"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if UIChecker.checkByResourceIdWait(id):
        d(resourceId=id).long_click()
    time.sleep(1)


def longClickByIdAndIndex(id, index):
    """匹配id和index,点击"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if UIChecker.checkByResourceIdWait(id):
        d(resourceId=id, index=index).long_click()
    time.sleep(1)


def clickByXY(x, y):
    """通过元素坐标点击"""
    adb_cmd("adb shell input tap %d %d" % (x, y))
    # time.sleep(1)


def clickByTextContains(name):
    """检查文本是否包含关键字
    存在返回1，否则返回0"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if UIChecker.checkByTextContainsWait(name):
        d(textContains=name).click()
    time.sleep(1)


def clickByResourceId(ResourceId):
    """匹配ResourceId，点击"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if UIChecker.checkByResourceId(ResourceId):
        d(resourceId=ResourceId).click()
    else:
        config.logger.debug("没有找到%s" % ResourceId)


def clickByResourceIdAndIndex(ResourceId, Index):
    """同时匹配ResourceId index，点击"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if UIChecker.checkByResourceId(ResourceId):
        d(resourceId=ResourceId, index=Index).click()


def clickByClassName(ClassName):
    """匹配类名，点击"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if UIChecker.checkByClassName(ClassName):
        d(className=ClassName).click()


def clickByClassNameAndIndex(ClassName, Index):
    """匹配类名 and index，点击"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if UIChecker.checkByClassName(ClassName):
        d(className=ClassName, index=Index).click()


def clickByScrollText(text, parent_resource_id=""):
    """滚动查找文本，点击"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if parent_resource_id:
        UIChecker.checkByScrollText(text, parent_resource_id)
    else:
        d(scrollable=True).scroll.to(text=text)
    if UIChecker.checkByTextWait(text):
        d(text=text).click()


def setTextByResourceId(ResourceId, text):
    """匹配ResourceId，设置文本"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    exist = UIChecker.checkByResourceIdWait(ResourceId)
    if exist:
        d(resourceId=ResourceId).set_text(text)
        config.logger.debug("%s控件输入 %s" % (ResourceId, text))


def fordsetTextByResourceId(ResourceId, text):
    """福特项目匹配ResourceId，设置文本
     增加收起键盘的操作 检查是否存在福特的百度输入发键盘"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    exist = UIChecker.checkByResourceIdWait(ResourceId)
    if exist:
        d(resourceId=ResourceId).set_text(text)
        config.logger.debug("%s控件输入 %s" % (ResourceId, text))
        if UIChecker.checkByResourceId("android:id/fullscreenArea"):
            clickByXY(993, 1099)
            if UIChecker.checkByResourceId("android:id/fullscreenArea"):
                clickByResourceId("com.baidu.xiaoduos.personalcenter:id/tv_vin")


def clearTextByResourceId(ResourceId):
    """匹配ResourceId，清除文本"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    exist = UIChecker.checkByResourceIdWait(ResourceId)
    if exist:
        d(resourceId=ResourceId).clear_text()


def getTextByResourceId(ResourceId):
    """匹配ResourceId，获取文本"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    exist = UIChecker.checkByResourceIdWait(ResourceId)
    if exist:
        return d(resourceId=ResourceId).text
    else:
        return None


def getTts0():
    """无延迟匹配tts文本"""
    tts = ""
    tts = getTextByResourceId("com.baidu.che.codriver:id/vrText")
    if tts != "":
        config.logger.debug("tts主题：" + "" + tts)
    else:
        config.logger.error("tts内容为空白")
    return tts

    time.sleep(1)


def getTts():
    """匹配ResourceId，获取文本"""
    exist = UIChecker.checkByResourceIdWait("com.baidu.che.codriver:id/vrText")
    if exist:
        time.sleep(2)
        tts = ""
        tts = getTextByResourceId("com.baidu.che.codriver:id/vrText")
        if tts != "":
            config.logger.debug("tts主题：" + "" + tts)
        #         config.logger.debug("tts描述：" + "" +getTextByResourceId("com.baidu.che.codriver:id/vrText"))
        else:
            config.logger.error("tts内容为空白")
        return tts
    else:
        config.logger.error("tts对话流没有展示出来")


def getContentDescByResourceId(ResourceId):
    """匹配ResourceId.获取内容描述"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    exist = UIChecker.checkByResourceIdWait(ResourceId)
    if exist:
        return d(resourceId=ResourceId).description
    else:
        return None


def getTextByResourceIdandIndex(ResourceId, Index):
    """匹配ResourceId，获取文本"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    exist = UIChecker.checkByResourceIdWait(ResourceId)
    if exist:
        return d(resourceId=ResourceId, index=Index).text
    else:
        return None


def getTextByResourceIdInstance(ResourceId, className, Instance):
    """匹配ResourceId className Instance，获取文本"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    exist = d(resourceId=ResourceId, className=className, instance=Instance).exists
    if not exist:
        return None
    return d(resourceId=ResourceId, className=className, instance=Instance).text


def getTextByIdChildclassNameAndIndex(ResourceId, className, Index):
    """匹配ID子类classname和index, 获取text"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    exist = d(resourceId=ResourceId).child(className=className, index=Index).exists
    if not exist:
        return None
    return d(resourceId=ResourceId).child(className=className, index=Index).text


def clearLog():
    """清除logcat buffer"""
    adb_cmd("adb logcat -c")


def open4G():
    """打开4G信号"""
    adb_cmd("adb shell svc data enable")


def close4G():
    """关闭4G信号"""
    adb_cmd("adb shell svc data disable")


def openWifi():
    """打开wifi信号"""
    adb_cmd("adb shell svc wifi enable")


def closeWifi():
    """关闭wifi信号"""
    adb_cmd("adb shell svc wifi disable")


def catchLog(name):
    """抓取log"""
    # name=sys._getframe().f_code.co_name
    log_path = os.path.join(GV().LOG_ROOT, "%s.txt" % name)
    os.popen("adb logcat >" + log_path)
    time.sleep(3)
    killProcess("logcat")


def getMethonName():
    """获取当前方法名"""
    return sys._getframe().f_code.co_name


def getCaseName(testcase):
    """获取case id"""
    list = testcase.id().split(".")
    list.pop(1)
    case_id = "_".join(list)
    return case_id


def catchCaseLog(testcase, filepath=GV().LOG_ROOT):
    """
    抓取当前case的日志
    :param testcase: 当前testcase
    :param filepath: 指定日志存储位置
    :return:
    """
    if isinstance(testcase, TestCase):
        case_name = getCaseName(testcase)
    else:
        case_name = testcase
    now = time.strftime("%Y%m%d%H%M%S", time.localtime(time.time()))
    file_name = "%s_%s.log" % (now, case_name)
    case_log = os.path.join(filepath, file_name)
    cmd = "adb -s %s logcat > %s" % (GV().device_id, case_log)
    os.popen(cmd)
    time.sleep(2)
    killProcess("logcat")
    clearLog()
    config.logger.debug("[case log] %s" % case_log)
    return case_log


def keyLogBuild(testcase, pattern):
    """抓取关键log到本地文件"""
    if isinstance(testcase, TestCase):
        case_id = getCaseName(testcase)
    else:
        case_id = testcase
    log_path = os.path.join(GV().LOG_ROOT, "%s_action.log" % case_id)
    case_log_file = catchCaseLog(testcase)
    GV().curr_result["log"] = case_log_file
    # findstr -E "*showVrNormal.*train_ticket." dueros_log.txt
    os.system('findstr -E -i "%s" %s > %s' % (pattern, case_log_file, log_path))
    # config.fail_files.append(log_path)
    return log_path


def keyLogDel():
    """删除本地关键log文件"""
    log_path = os.path.join(GV().LOG_ROOT, "action.log")
    os.remove(log_path)


def security():
    """连接设备，并解除安全限制"""
    # 等待设备连接
    adb_cmd("adb wait-for-device")
    # GV().adb.raw_cmd("wait-for-device")
    # Action.adb_cmd("adb wait-for-device")
    # 获取root权限
    adb_cmd("adb root")
    # Action.adb_cmd("adb root")
    # 解除安全防护
    adb_cmd("adb shell setprop bdcarsec.pm.uninstall 0")
    adb_cmd("adb shell setprop bdcarsec.pm.install 0")
    adb_cmd("adb shell setprop bdcarsec.am.run.verifyprocess 0")
    adb_cmd("adb shell setprop bdcarsec.time.scan 0")


def quick_wifi_on():
    """快捷开启WIFI"""
    adb_cmd("adb shell svc wifi enable")
    waiting(2)


def quick_wifi_off():
    """快捷关闭WIFI"""
    adb_cmd("adb shell svc wifi disable")
    waiting()


def initU2():
    """初始化Uiautomator2"""
    if GV().device_id:
        os.system("python -m uiautomator2 init -s %s" % GV().device_id)


def resetUiautomatorServer():
    """
    重连机制
    """
    config.logger.debug("device id : %s" % GV().device_id)
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    d.server.install()


def dialNumber(number):
    """
    !!此方法的前提为进入电话
    点击拨号tab页，输入号码，点击拨号
    """
    # 点击切换到拨号tab页
    clickByResourceId("com.baidu.xiaoduos.dialer:id/rb_callpan")
    # 判断如果当前有输入的号码就清空
    while UIChecker.checkByResourceId(
            "com.baidu.xiaoduos.dialer:id/btn_call_pan_delete"
    ):
        clickByResourceId("com.baidu.xiaoduos.dialer:id/btn_call_pan_delete")
    for num in number:
        if num == "*":
            num = 10
        elif num == "#":
            num = 11
        clickByResourceId("com.baidu.xiaoduos.dialer:id/tv_call_pan_key_" + num)


def dialCall(number, delay):
    """
    !!此方法的前提为进入电话
    点击拨号tab页，输入号码，点击拨号
    """
    dialNumber(number)
    time.sleep(delay)


def endCall():
    """
    挂断电话
    """
    if UIChecker.checkByResourceIdWait("com.baidu.xiaoduos.dialer:id/btn_hang_up"):
        clickByResourceId("com.baidu.xiaoduos.dialer:id/btn_hang_up")
        time.sleep(5)


def enterMap():
    """
    从launcher主页卡片点击进入应用
    进入地图
    """
    adb_cmd("adb shell input keyevent 3")
    clickByText("百度地图")


def enterDialer():
    """
    从Launcher主页卡片进入电话
    """
    adb_cmd("adb shell input keyevent 3")
    swipeRightAtBottom()
    clickByTextContains("电话")


def backToPre():
    """
    返回上一页
    """
    adb_cmd("adb shell input keyevent 4")


def backToHome():
    """
    返回主页
    """
    adb_cmd("adb shell input keyevent 3")


def enter_from_system_ui(menu_name, resource_id='android:id/navigationBarBackground'):
    """
    通过导航栏进入各个应用
    :param resource_id:
    :param menu_name:
    :return:
    """
    system_ui_menu = ['navi', 'music', 'home', 'car', 'more']
    index = system_ui_menu.index(menu_name)
    # print(index)
    if index >= 0:
        # bounds = UIChecker.getViewBounds(resource_id)
        # print(bounds)
        x = 120 / 2
        y = 720 / len(system_ui_menu) / 2
        # x = (bounds['right'] - bounds['left'])/2
        # y = (bounds['bottom'] - bounds['top'])/len(system_ui_menu)/2
        clickByXY(x, (index * 2 + 1) * y)


def close_app(package_name):
    """
    关闭指定包名的应用
    :param package_name: 关闭应用的包名
    :return:
    """
    adb_cmd('adb shell am force-stop "%s"' % package_name)
    waiting(2)


def swipeLeftAtCenter():
    "在屏幕中间向左滑动"
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    d.swipe(
        d.displaySizeDpX * (3 / 4),
        d.displaySizeDpY / 2,
        d.displaySizeDpX / 4,
        d.displaySizeDpY / 2,
        steps=10,
    )


def swipeLeftAtBottom():
    "在屏幕底部向左滑动"
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    d.swipe(
        d.displaySizeDpX * (3 / 4),
        d.displaySizeDpY,
        d.displaySizeDpX / 4,
        d.displaySizeDpY,
        steps=10,
    )


def swipTopOnLandspace():
    """横屏向上滑动"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    dpx1 = d.displaySizeDpX / 4
    dpy1 = d.displaySizeDpY / 4 * 3
    dpx2 = d.displaySizeDpX / 4
    dpy2 = d.displaySizeDpY / 4
    # print("adb shell input swipe %d %d %d %d 10" % (dpx1, dpy1, dpx2, dpy2))
    adb_cmd("adb shell input swipe %d %d %d %d 1000" % (dpx1, dpy1, dpx2, dpy2))


def swipeRightAtCenter():
    "在屏幕中间向右滑动"
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    d.swipe(
        d.displaySizeDpX / 4,
        d.displaySizeDpY / 2,
        d.displaySizeDpX * (3 / 4),
        d.displaySizeDpY / 2,
        steps=10,
    )


def swipeRightAtBottom():
    """在屏幕底部向右滑动"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    d.swipe(
        d.displaySizeDpX / 4,
        d.displaySizeDpY,
        d.displaySizeDpX * (3 / 4),
        d.displaySizeDpY,
        steps=10,
    )


def clickIdChildClass(Id, className, index):
    """..."""
    # 通过id找到子类，再按照index点击对应控件
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    d(resourceId=Id).child(className=className, index=index).click()


def setIdChildClass(Id, indexs, id, text):
    """
    通过id找到子类，再按照index点击对应控件
    :param Id:
    :param indexs:
    :param id:
    :param text:
    :return:
    """
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    d(className=Id, index=indexs).child(resourceId=id).set_text(text)


def getIdChildClass(Id, className, index):
    """
    通过id找到子类，再按照index查找对应控件
    :param Id:
    :param className:
    :param index:
    :return:
    """
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    return d(resourceId=Id).child(className=className).text


def getIdChildClasss(Id, className, index):
    """
    通过id找到孙子类，再按照index点击对应控件，获取其text
    :param Id:
    :param className:
    :param index:
    :return:
    """
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    return d(resourceId=Id).child().child(className=className, index=index).text


def clickIdChildClasss(Id, className, className1, index):
    """
    通过id找到孙子类，再按照index点击对应控件，获取其text
    :param Id:
    :param className:
    :param className1:
    :param index:
    :return:
    """
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    d(resourceId=Id).child(className=className1).child(className=className, index=index).click()


def clickIdChildIndexClasss(Id, className, index1, className1, index2):
    """
    通过id找到孙子类，再按照index点击对应控件，获取其text
    :param Id:
    :param className:
    :param index1:
    :param className1:
    :param index2:
    :return:
    """
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    d(resourceId=Id).child(className=className1, index=index1).child(className=className, index=index2).click()


def clickIdIndexChildIndexClasss(Id, index, className1, index1, className2, index2):
    """
    通过id找到孙子类，再按照index点击对应控件，获取其text
    :param Id:
    :param index:
    :param className1:
    :param index1:
    :param className2:
    :param index2:
    :return:
    """
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    d(resourceId=Id,
      index=index).child(className=className1,
                         index=index1).child(className=className2,
                                             index=index2).click()


def logcatCatch(logPath):
    """
    清空异常log目录，logcat抓取
    :param logPath:
    :return:
    """
    adb_cmd("adb root")
    # 清空历史log
    adb_cmd("adb shell rm -rf /data/anr/*")
    adb_cmd("adb shell rm -rf /data/system/dropbox/*")
    adb_cmd("adb shell rm -rf data/tombstones/*")
    # 设置buffer
    adb_cmd("adb logcat -G 10m")
    os.popen(
        "adb logcat -b system -b main -b events -b crash -b kernel > "
        + logPath
        + "/MTBF_logcat.txt"
    )


def logExport(logPath):
    """
    导出异常log
    :param logPath:
    :return:
    """
    adb_cmd("adb root")
    adb_cmd("adb wait-for-device")
    # 导出anr/dropbox 文件
    adb_cmd("adb pull /data/anr " + logPath)
    adb_cmd("adb pull /data/system/dropbox " + logPath)
    adb_cmd("adb pull /data/tombstones " + logPath)
    adb_cmd("adb kill-server")
    adb_cmd("adb start-server")


def close():
    """
    该方法主要用途是为了关闭地图操作成功后的提示，该提示会遮挡住后续脚本的
    控件（该提示会存在3s左右的时间）会影响后续脚本的定位，避免后面每个脚本都
    加入定时的等待时间，所以加了关闭提示的方法
    :return:
    """
    if UIChecker.checkByText("关闭"):
        clickByText("关闭")


def swipeDiretion(Id, Diretion, num=20):
    """

    :param Id:
    :param Diretion:
    :param num:
    :return:
    """
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    exist = UIChecker.checkByResourceIdWait(Id)
    if exist:
        if Diretion == "down":
            d(resourceId=Id).swipe.down(steps=num)
        if Diretion == "up":
            d(resourceId=Id).swipe.up(steps=num)
        if Diretion == "left":
            d(resourceId=Id).swipe.left(steps=num)
        if Diretion == "right":
            d(resourceId=Id).swipe.right(steps=num)


def viewshot(resourceId, view_path):
    """
    截取指定资源id的控件，存放在指定目录下
    :param resourceId:
    :param view_path:
    :return:
    """
    pic_path = screenshot()
    img = Image.open(pic_path)
    bounds = UIChecker.getViewBounds(resourceId)
    bbox = (bounds['left'], bounds['top'], bounds['right'], bounds['bottom'])
    cropped = img.crop(bbox)
    cropped.save(view_path)
    config.logger.debug("[viewshot]%s-->%s" % (resourceId, view_path))


def screenshot(msg=None):
    """

    :param msg:
    :return:
    """
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if msg:
        pic_name = "%s%s.png" % (now(), msg)
    else:
        pic_name = "%s.png" % (now())
    pic_path = os.path.join(config.SCREENSHOT_DIR, pic_name)

    adb_cmd("adb shell screencap -p /sdcard/test.png")
    adb_cmd("adb pull /sdcard/test.png %s" % pic_path)
    return pic_path


def waiting(sec=5):
    """

    :param sec:
    :return:
    """
    time.sleep(sec)


def musicPause():
    """
    音乐暂停
    :return:
    """
    adb_cmd("adb shell am broadcast -a com.baidu.car.radio.PAUSE")


def musicPlay():
    """
    播放音乐
    :return:
    """
    adb_cmd("adb shell am broadcast -a com.baidu.car.radio.PLAY")


def isElementExist(self, ResourceId):
    """
    该方法用来确认元素是否存在，如果存在返回flag=true，否则返回false
    :return:
    """
    flag = True
    browser = self.driver
    try:
        browser.find_element_by_css_selector(ResourceId)
        return flag
    except:
        flag = False
        return flag


def SlipFindText(text):
    """

    :param text:
    :return:
    """
    count = 0
    config.logger.info(text)
    while (not UIChecker.checkByText(text)):
        swipeRightAtBottom()
        waiting(1)
        count = count + 1
        if count > 8:
            break
    while (not UIChecker.checkByText(text)):
        swipeLeftAtBottom()
        waiting(1)
        count = count + 1
        if count > 8:
            break


def getCaseInfo(casepath):
    """
    获取caseinfo
    :param casepath: testcase.id()
    :return:
    """
    case_info = {}
    # config.logger.debug("case path: %s" % casepath)
    array = casepath.split(".")
    array.pop(-2)
    module_name = "-".join(array[:-2])
    method_name = casepath.split(".")[-1]
    # GV().module_name = module_name.lower()
    # if not GV().module_name.isalpha():
    #     #     module_name = module_name[3:]
    #     # config.logger.debug("case.id@@@@%s%s" % (str(array[:-2]), str(array[-2:])))
    case_info["module_name"] = module_name.lower()
    case_info["module_tag"] = Common.get_module_name(module_name)
    case_info["id"] = "%s_%s" % (case_info["module_name"], "".join(array[-2:]).replace("test_", ""))
    case_info["method_name"] = method_name
    case_id_list = list("".join([i.replace("test_", "") for i in array[-2:]]))
    if len(case_id_list) == 7:
        case_info["priority"] = int(case_id_list.pop(3))
        case_info["new_id"] = "%s_%s" % (case_info["module_name"], "".join(case_id_list))
    return case_info


def set_cores_by_index(cores=[0, 1, 2, 3], state=0):
    """
    设置使用CPU情况
    :param cores:
    :param state: 0 关闭 1 开启
    :return:
    """
    for index in cores:
        adb_cmd(
            'adb shell "echo "%d" > /sys/devices/system/cpu/cpu%d/online"'
            % (state, index)
        )
    cores_info = adb_popen("adb shell cat /sys/devices/system/cpu/online")
    config.logger.debug("online cores: %s" % cores_info)


def getCasePath(module, id):
    """
    拼接case完整目录
    :param module:
    :param id:
    :return:
    """
    config.logger.debug(module.isalpha())
    if not module.isalpha():
        raise NameError
    casepath = "%s.%s" % (module, id)
    return casepath


def report(arg, result):
    """
    上报case信息和执行结果
    :param arg:
    :param result:
    :return:
    """
    if GV().module_name != "":
        config.logger.info("~~~~~~report~~~~~~~")
        now_date = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        casepath = arg.id()
        caseinfo = getCaseInfo(casepath)
        methodname = caseinfo["method_name"]
        module_name = caseinfo["module_name"]
        case_id = caseinfo["id"]
        package_name = getattr(arg, "package_name")
        launch_activity = getattr(arg, "launch_activity")
        case_author = getattr(getattr(arg, methodname), "author")
        caseinfo["author"] = case_author
        modified_time = getattr(getattr(arg, methodname), "datetime")
        case_type = getattr(getattr(arg, methodname), "type")
        case_name = getattr(getattr(arg, methodname), "__doc__")
        caseinfo["name"] = case_name
        config.logger.debug("case_id:%s;case_name:%s;case_author:%s;modified_time:%s;case_type:%s" % (
            case_id, case_name, case_author, modified_time, case_type))
        Common.insert_into_caseinfo(case_id, case_name, case_author, module_name, package_name, launch_activity,
                                    caseinfo["priority"], int(case_type), modified_time)
        config.logger.debug("report case info to database")
        Common.insert_into_testresult(case_id, result, GV().START_TIME, now_date)
        config.logger.debug("report case result to database:%s" % str(result))
        if result["result"] == False and GV().module_name == "all":
            config.logger.debug("create issue for rom_auto！")
            bugbuilder.create_issue_romauto(
                caseinfo,
                str(result),
                module=caseinfo["module_tag"],
                type="Bug",
                emailto=["%s@baidu.com" % case_author],
                owner=case_author)
        if case_type == 1:
            # 上传性能数据
            config.logger.debug("ready to upload perf data for rom_auto！")


def swipeDiretions(x, y, xe, ye):
    """固定滑屏"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    d.swipe(x, y, xe, ye)


def timesleepID(id):
    """安ResourceId智能等待"""
    for i in range(30):
        if UIChecker.checkByResourceId(id) == 1:
            break
        else:
            time.sleep(1)


def timesleepText(text):
    """

    :param text:
    :return:
    """
    """按Text智能等待"""
    for i in range(30):
        if UIChecker.checkByText(text) == 1 or UIChecker.checkByTextContains(text) == 1:
            break
        else:
            time.sleep(1)


def getTextByClassandIndexChildResourceId(className, index, Id):
    """

    :param className:
    :param index:
    :param Id:
    :return:
    """
    # 通过class和index找到子类下ID, 获取text
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    return d(className=className, index=index).child(resourceId=Id).text


def getTextByClassandIndex(className, index):
    """

    :param className:
    :param index:
    :return:
    """
    # 通过class和index找到子类下ID, 获取text
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    return d(className=className, index=index).text


def getTextByResourceIdChildResourceIdandIndex(ResourceId, resourceId, Index):
    """

    :param ResourceId:
    :param resourceId:
    :param Index:
    :return:
    """
    # 通过id找到子类下ID和index, 获取text
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    return d(resourceId=ResourceId).child(resourceId=resourceId, index=Index).text


def clickClassandindexChildResourceId(className, index, Id):
    """

    :param className:
    :param index:
    :param Id:
    :return:
    """
    # 通过class和index找到子类下ID, 进行点击
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    return d(className=className, index=index).child(resourceId=Id).click()


def clickResourceIdChildClassAndIndex(ResourceId, className, index):
    """

    :param ResourceId:
    :param className:
    :param index:
    :return:
    """
    # 通过class和index找到子类下ID, 进行点击
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    return d(resourceId=ResourceId).child(className=className, index=index).click()


def getContentDescByClassChildclassandindex(className, classname, Index):
    """

    :param className:
    :param classname:
    :param Index:
    :return:
    """
    """匹配class下的子类class.获取内容描述"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    return d(className=className).child(className=classname, index=Index).description


def getTextByResourceIdChildResourceId(ResourceId, resourceId):
    """

    :param ResourceId:
    :param resourceId:
    :return:
    """
    # 通过id找到子类下ID, 获取text
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    return d(resourceId=ResourceId).child(resourceId=resourceId).text


def swipeTop():
    """
    屏幕底部滑倒最顶部-不通用后续再优化
    :return:
    """

    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    for i in range(4):
        d.swipe(144, 360, 144, 926)


def swipeToptoDown():
    """
    屏幕往下滑到底部
    :return:
    """

    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    for i in range(2):
        d.swipe(744, 960, 144, 326)


def swipeNext(num):
    """
    屏幕底部滑倒最顶部-不通用后续再优化
    :param num:
    :return:
    """
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    for i in range(num):
        d.drag(144, 790, 144, 360)
        # d.swipe(144, 792, 144, 360)
        time.sleep(3)


def openFordProcess(name):
    """快捷打开福特进程"""
    if name == "随心听" or name == "多媒体":
        adb_popen("adb shell am start  com.baidu.car.radio")
    elif name == "随心看" or name == "爱奇艺":
        adb_popen("adb shell am start  com.baidu.iov.dueros.videoplayer")
    elif name == "车控家":
        adb_popen("adb shell am start  com.baidu.iov.dueros.car2home")
    elif name == "外卖":
        adb_popen("adb shell am start  com.baidu.iov.dueros.waimai")
    elif name == "电影":
        adb_popen("adb shell am start  com.baidu.iov.dueros.film")
    elif name == "酒店":
        adb_popen("adb shell am start  com.baidu.iov.dueros.hotel")
    elif name == "ETCP" or name == "智慧停车场":
        adb_popen("adb shell am start  com.baidu.che.parking")
    elif "设置" in name:
        adb_popen("adb shell am start  com.baidu.xiaoduos.setting/.activitys.MainActivity")
    elif "个人中心" == name:
        adb_popen("adb shell am start  com.baidu.xiaoduos.personalcenter")
    else:
        config.logger.error("没有找到匹配的方法名，请自行添加")


def killFordProcess(name):
    """快捷杀死福特项目进程"""
    if name == "随心听" or name == "多媒体":
        adb_popen("adb shell am force-stop com.baidu.car.radio")
    elif name == "随心看" or name == "爱奇艺":
        adb_popen("adb shell am force-stop com.baidu.iov.dueros.videoplayer")
    elif name == "车控家":
        adb_popen("adb shell am force-stop com.baidu.iov.dueros.car2home")
    elif name == "外卖":
        adb_popen("adb shell am force-stop com.baidu.iov.dueros.waimai")
    elif name == "电影":
        adb_popen("adb shell am force-stop com.baidu.iov.dueros.film")
    elif name == "酒店":
        adb_popen("adb shell am force-stop com.baidu.iov.dueros.hotel")
    elif name == "ETCP" or name == "智慧停车场":
        adb_popen("adb shell am force-stop com.baidu.che.parking")
    elif name == "个人中心":
        adb_popen("adb shell am force-stop com.baidu.xiaoduos.personalcenter")
    elif "设置" in name:
        adb_popen("adb shell am force-stop com.baidu.xiaoduos.setting/.activitys.MainActivity")
    else:
        config.logger.error("没有找到匹配的方法名，请自行添加")


def dueros_recognise(receive_words):
    """
    语音指令快捷识别
    :param receive_words: 上屏的文字
    :return:
    """
    adb_cmd("adb shell am broadcast -a vr.intent.action.QUERY --es query %s" % receive_words)
    waiting(3)


if __name__ == '__main__':
    # 第1个 Event().viewshot(switch_id, view_path, 144, 360, 1776, 504)
    # 第2个Event().viewshot(switch_id, view_path, 144, 504, 1776, 648)
    # 第3个 Event().viewshot(switch_id, view_path, 144, 648, 1776, 792)
    # 第4个 Event().viewshot(switch_id, view_path, 144, 792, 1776, 936)
    # 第5个 Event().viewshot(switch_id, view_path, 144, 936, 1776, 1080)
    # swipeNext(1)
    # swipeNext(1)

    # clearLog()
    # print(make_sure_login(2))
    # enterAppFromMore("车机管家")
    # enterAppFromMore("技能广场")
    # test11 = getCaseInfo("rom.launcher.test_001.MyTest.test_0103")
    # print(test11)

    # package_name = "com.baidu.xiaoduos.recommend"
    # event_id = "REC900001"
    # # event_type = 1
    # # start_time = time.time()
    # clearLog()
    # print(time.time())
    # a = "*onEvent: packageName=%s,*.*eventId=%s" % (package_name, event_id)
    # print(a)
    # # do something
    # waiting(2)
    # print(time.time())
    # print(keyLogBuild("test", a))
    # case.id @ @ @ @ ['rom', 'launcher']['test_001', 'test_0103']
    # print(getCaseInfo("rom.launcher.test_001.MyTest.test_0103"))
    # print(getCasePath("rom/launcher", "xxx.xxxx01"))
    # print("hahahaha")
    # keyLogBuild("SdkUpdate")
    # str = "13_userguide"
    # dueros_recognise("打开随心听")
    print(get_package_info_by_tag("com.baidu.xiaoduos.launcher", tag="userId"))
