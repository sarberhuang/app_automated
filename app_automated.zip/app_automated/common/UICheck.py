#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

"""

import time

from common.Adb import Adb

wait_time = 12000
timeout = 5000


def check_exists_wait(device, mode, **kwargs):
    """
    兼容uiautomator1、2
    :param device:
    :param mode:
    :param kwargs:
    :return:
    """
    d = Adb.get_device(device, mode)
    if mode == 1:
        return d(**kwargs).wait.exists(timeout=wait_time)
    elif mode == 2:
        return d(**kwargs).exists(timeout=wait_time)

def check_exists_nowait(device, mode, **kwargs):
    """
    兼容uiautomator1、2
    :param device:
    :param mode:
    :param kwargs:
    :return:
    """
    d = Adb.get_device(device, mode)
    if mode == 1:
        return d(**kwargs).wait.exists(timeout=1000)
    elif mode == 2:
        return d(**kwargs).exists(timeout=1000)

# d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
#
# def check_ctrls_wait_exists_by_text(d, controls_text):
#     """通过文本检查控件是否存在，并等待wait_time时间
#     Args:
#         d: uiautomatior devicea
#         controls_text: Android control text
#     Returns:
#         Int: 0 or 1
#     """
#     if d(text=controls_text).exists(timeout=wait_time):
#         return 1
#     else:
#         return 0
#
#
# def check_ctrls_wait_exists_by_resource_id(d, resource_id):
#     """通过resource id检查控件是否存在，并等待wait_time时间
#     Args:
#         d: uiautomatior device
#         resource_id: Android control text
#     Returns:
#         Int: 0 or 1
#     """
#     if d(resourceId=resource_id).exists(timeout=wait_time):
#         return 1
#     else:
#         return 0
#
#
# def check_ctrls_wait_exists_by_id_and_index(d, resource_id, i):
#     """通过resource_id和index检查控件是否存在，并等待wait_time时间
#     Args:
#         d: uiautomatior device
#         resource_id: Android control id
#         i: index
#     Returns:
#         Int: 0 or 1
#     """
#     if d(resourceId=resource_id, index=i).exists(timeout=wait_time):
#         return 1
#     else:
#         return 0
#
#
# def check_ctrls_exists_by_text(d, controls_text):
#     """通过文本检查控件是否存在
#     Args:
#         d: uiautomatior device
#         controls_text: Android control text
#     Returns:
#         Int: 0 or 1
#     """
#     if d(text=controls_text).exists:
#         return 1
#     else:
#         return 0
#
#
# def check_ctrls_exists_by_resource_id(d, resource_id):
#     """通过resource id检查控件是否存在
#     Args:
#         d: uiautomatior device
#         resource_id: Android control text
#     Returns:
#         Int: 0 or 1
#     """
#     if d(resourceId=resource_id).exists:
#         return 1
#     else:
#         return 0
#
#
# def check_ctrls_exists_by_id_and_index(d, resource_id, i):
#     """通过resource_id和index检查控件是否存在
#     Args:
#         d: uiautomatior device
#         resource_id: Android control id
#         i: index
#     Returns:
#         Int: 0 or 1
#     """
#     if d(resourceId=resource_id, index=i).exists:
#         return 1
#     else:
#         return 0
#
#
# def check_controls_checked_by_resource_id(d, resource_id, flag):
#     """通过resource_id，判断checked选项为true or false
#     Args:
#         d: uiautomatior device
#         resource_id: Android control id
#         flag: true or false
#     Returns:
#         Int: 0 or 1
#     """
#     if d(resourceId=resource_id).info['checked'] == flag:
#         return 1
#     else:
#         return 0
#
#
# def check_controls_checked_by_text(d, content, flag):
#     """通过text，判断checked选项为true or false
#     Args:
#         d: uiautomatior device
#         text: text
#         flag: true or false
#     Returns:
#         Int: 0 or 1
#     """
#     if d(text=content).info['checked'] == flag:
#         return 1
#     else:
#         return 0
#
#
# def check_text(d, resource_id, text):
#     """判断id为resourceid的控件 text是否符合预期
#     Args:
#         d: uiautomatior device
#         resource_id: Android control resource_id
#         text: expected text
#     Returns:
#         Int: 0 or 1
#     """
#     if d(resourceId=resource_id).info['text'] == text:
#         return 1
#     else:
#         return 0
#
#
# def check_controls_click_text(d, controls_text):
#     """判断按钮是否置灰 & text & clickable
#     Args:
#         d: uiautomatior device
#         controls_text: Android control text
#     Returns:
#         Int: 0 or 1
#     """
#     if d(text=controls_text).info['clickable'] is True:
#         return 1
#     else:
#         return 0
#
#
# # assertIn(a, b)     a in b
# def check_ainb(d, resource_id, b):
#     """判断控件文本是否包含在b中
#     Args:
#         d: uiautomatior device
#         resource_id: Android control resource id
#     Returns:
#         Int: 0 or 1
#     """
#     if d(resourceId=resource_id).info['text'] in b:
#         return 1
#     else:
#         return 0
#
#
def check_controls_click_enabled_by_resource_id(d, resource_id):
    """判断控件是否可点击
    Args:
        d: uiautomatior device
        resource_id: Android control resource id
    Returns:
        Int: 0 or 1
    """
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(resourceId=resource_id).info["enabled"]:
        return 1
    else:
        return 0


def check_controls_click_enabled(resource_id):
    """判断控件是否可点击(正确版)
    Args:
        d: uiautomatior device
        resource_id: Android control resource id
    Returns:
        Int: 0 or 1
    """
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(resourceId=resource_id).info["enabled"]:
        return 1
    else:
        return 0


#
# '''
# def check_controls_exists_by_resource_id_appium(driver, resource_id):
#     """通过resource id检查控件是否存在 - for appium
#     Args:
#         driver: appium webdriver
#         resource_id: Android control resource id
#     Returns:
#         Int: 0 or 1
#     Raises:
#         NoSuchElementException: An error occurred when element doesn't exist
#     """
#     try:
#         if driver.find_element_by_id(resource_id).is_displayed():
#             return 1
#         else:
#             return 0
#     except NoSuchElementException as e:
#         raise e
#         return 0
# '''
#
#
#
# def checkTest(name):
#     """
#     checkTest(name) -> int
#
#     检查匹配的文本是否存在
#     :param
#         name: 控件上显示的文本
#     :return:
#         1: 存在
#         0: 不存在
#     """
def checkByText(name):
    """
    checkTest(name) -> int

    检查匹配的文本是否存在
    存在返回1，否则返回0
    """
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(text=name).exists:
        return 1
    else:
        config.logger.error("没有找到%s" % name)
        return 0

def checkPop():
    """
    checkpop 检测当前页面是否有弹框，目前发现3个比较经典的授权服务弹框，地图免责声明弹框，以及qq音乐弹框(截图发hi群里)
    这些都会影响case的进程，目前简单处理了一下福特竖屏和林肯的
    自动化case中调用方法  UIChecker.checkPop()
    """
    if checkByResourceId("com.baidu.iov.faceos:id/btn_cancel"):
        config.logger.debug("福特竖屏的授权弹框，点击授权取消弹框")
        Action.clickByText("授权")
        Action.clickByTextContains("关闭")
        config.logger.debug("福特竖屏的授权弹框，授权成功，且关闭掉弹框")
    if checkByResourceId("com.baidu.naviauto:id/content_msg"):
        config.logger.debug("福特竖屏地图的免责声明弹框")
        Action.clickByText("接受")
        config.logger.debug("福特竖屏的免责声明弹框，接受协议")
    if checkByResourceId("com.baidu.car.radio:id/tv_wx_login"):
        config.logger.debug("福特竖屏qq音乐登录弹框")
        Action.clickByText("微信登录")
        config.logger.debug("福特竖屏的竖屏qq音乐登录弹框，进入登录操作")
        time.sleep(5)
        Action.adb_cmd("adb shell screencap -p > %s/qqmusic_login.png" % config.SCREENSHOT_DIR)
        pic_path = config.SCREENSHOT_DIR + "/" + "qqmusic_login.png"
        CompressPicture.ChangePictureSize(pic_path, "png", "jpg")
        img_string = CompressPicture.TansPicture2Base64(pic_path)

    if checkByResourceId("com.baidu.iov.faceos:id/tv_title_alone_content"):
        config.logger.debug("林肯的授权弹框，点击授权取消弹框")
        Action.clickByText("授权")
        Action.clickByTextContains("关闭")
        config.logger.debug("林肯的授权弹框，授权成功，且关闭掉弹框")
    if checkByResourceId("com.baidu.naviauto:id/dialog_content"):
        config.logger.debug("林肯地图的免责声明弹框")
        Action.clickByText("接受")
        config.logger.debug("林肯地图的免责声明弹框，接受协议")

    else:
        config.logger.error("tts没有展示出来")

def checkByTextContains(name):
    """检查文本是否包含关键字
    存在返回1，否则返回0"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(textContains=name).exists:
        return 1
    else:
        config.logger.error("没有找到%s" % name)
        return 0


def checkByResourceId(name):
    """检查匹配的ResourceId是否存在
    存在返回1，否则返回0"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(resourceId=name).exists:
        return 1
    else:
        config.logger.error("没有找到%s" % name)
        return 0


def checkByClassName(name):
    """检查匹配的类名是否存在
    存在返回1，否则返回0"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(className=name).exists:
        return 1
    else:
        config.logger.error("没有找到%s" % name)
        return 0

def checkByXpath(name):
    """检查匹配的类名是否存在
    存在返回1，否则返回0"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(xapth=name).exists:
        return 1
    else:
        config.logger.error("没有找到%s" % name)
        return 0

def checkByPackageName(name):
    """检查匹配的包名是否存在
    存在返回1，否则返回0"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(packageName=name).exists:
        return 1
    else:
        config.logger.error("没有找到%s" % name)
        return 0


def checkByTextWait(name):
    """检查匹配的文本是否存在"""
    # d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if check_exists_wait(GV().device_id, GV().AUTO_MODE, text=name):
        return 1
    else:
        config.logger.error("没有找到%s" % name)
        return 0


def checkBychild(Id, className, index):
    """检查匹配的文本是否存在"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(resourceId=Id).child(className=className, index=index):
        return 1
    else:
        config.logger.error("没有找到%s->%s->%d" % (Id, className, index))
        return 0


def checkfromchild(className, index, Id):
    """检查匹配的文本是否存在"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(className=className, index=index).child(resourceId=Id):
        return 1
    else:
        config.logger.error("没有找到%s->%s->%d" % (Id, className, index))
        return 0


def checkByTextContainsWait(name):
    """检查查找的文本是否包含关键字"""
    # d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if check_exists_wait(GV().device_id, GV().AUTO_MODE, textContains=name):
        return 1
    else:
        config.logger.error("没有找到%s" % name)
        return 0


def checkByResourceIdWait(name):
    """检查匹配的ResourceId是否存在"""

    if check_exists_wait(GV().device_id, GV().AUTO_MODE, resourceId=name):
        return 1
    else:
        config.logger.error("没有找到%s" % name)
        return 0


def checkByIdAndText(id, name):
    """check"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(resourceId=id, text=name).exists:
        return 1
    else:
        config.logger.error("没有找到%s->%s" % (id, name))
        return 0


def checkByIdAndTextWait(id, name):
    """

    :param id:
    :param name:
    :return:
    """
    # d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if check_exists_wait(GV().device_id, GV().AUTO_MODE, resourceId=id, text=name):
        return 1
    else:
        config.logger.error("没有找到%s->%s" % (id, name))
        return 0


def checkByClassNameWait(name):
    """检查匹配的类名是否存在"""
    # d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if check_exists_wait(GV().device_id, GV().AUTO_MODE, className=name):
        return 1
    else:
        config.logger.error("没有找到%s" % name)
        return 0


def checkByPackageNameWait(name):
    """检查匹配的包名是否存在"""
    # d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if check_exists_wait(GV().device_id, GV().AUTO_MODE, packageName=name):
        return 1
    else:
        config.logger.error("没有找到%s" % name)
        return 0


def isBaiduMap():
    """
    是否进入地图成功
    :return:
    """
    Action.waiting(3)
    # 处理允许拍照弹框
    Action.clickByText("允许")
    if checkByResourceId("com.android.packageinstaller:id/permission_allow_button"):
        Action.clickByText("允许")
        Action.waiting(2)
    # 处理免责声明
    if checkByText("免责声明"):
        Action.clickByText("接受")
    if check_exists_wait(GV().device_id, GV().AUTO_MODE, packageName='com.baidu.naviauto'):
        return 1
    else:
        return 0


def checkByScrollText(name, parent_resource_id="", orientation=""):
    """滚动查找匹配的文本是否存在"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(text=name).exists:
        return 1
    elif parent_resource_id:
        if orientation == "|":
            d(resourceId=parent_resource_id).scroll.vert.toBeginning()
            d(resourceId=parent_resource_id).scroll.vert.to(text=name)
            config.logger.debug("scroll.vert")
        elif orientation == "-":
            d(resourceId=parent_resource_id).scroll.horiz.toBeginning()
            d(resourceId=parent_resource_id).scroll.horiz.to(text=name)
            config.logger.debug("scroll.horiz")
        else:
            d(resourceId=parent_resource_id).scroll.toBeginning()
            d(resourceId=parent_resource_id).scroll.to(text=name)
            config.logger.debug("scroll.")
    elif d(scrollable=True).exists:
        d(scrollable=True).scroll.to(text=name)
        config.logger.debug("scroll...")
    if d(text=name).exists:
        return 1
    else:
        config.logger.error("没有找到%s" % name)
        return 0


def checkByScrollResourceId(name):
    """滚动查找匹配的ResourceId是否存在"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(scrollable=True).exists:
        d(scrollable=True).scroll.to(resourceId=name)
    if d(resourceId=name).exists:
        return 1
    else:
        config.logger.error("没有找到%s" % name)
        return 0


def checkByScrollClassName(name):
    """滚动查找匹配的类名是否存在"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(scrollable=True).exists:
        d(scrollable=True).scroll.to(className=name)
    if d(className=name).exists:
        return 1
    else:
        config.logger.error("没有找到%s" % name)
        return 0


def checkByScrollPackageName(name):
    """滚动查找匹配的包名是否存在"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(scrollable=True).exists:
        d(scrollable=True).scroll.to(packageName=name)
    if d(packageName=name).exists:
        return 1
    else:
        config.logger.error("没有找到%s" % name)
        return 0


def checkButtonStatusByID(name):
    """检查按钮选中状态
    true返回1
    否则返回0"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(resourceId=name).checked == True:
        return 1
    else:
        config.logger.error("没有找到%s" % name)
        return 0


def checkSelectedStatusByID(name):
    """检查按钮选中状态
    true返回1
    否则返回0"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(resourceId=name).selected == True:
        return 1
    else:
        config.logger.error("没有找到%s" % name)
        return 0


def checkSelectedStatusByText(name):
    """检查按钮选中状态
    true返回1
    否则返回0"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(text=name).selected == True:
        return 1
    else:
        return 0


def checkButtonStatusByText(name):
    """检查按钮选中状态
    true返回1
    否则返回0"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(text=name).checked == True:
        config.logger.debug("%s被选中" % name)
        return 1
    else:
        config.logger.error("%s未选中" % name)
        return 0

def getViewBounds(resource_id):
    """
    获取控件
    :param resource_id:
    :return:
    """
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    bounds = d(resourceId=resource_id).info['bounds']
    config.logger.debug(bounds)#{'bottom': 201, 'left': 1614, 'right': 1692, 'top': 165}
    return bounds

def checkSwitchStatusById(name):
    """检查按钮选中状态
    true返回1
    否则返回0"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d(resourceId=name).checked == True:
        return 1
    else:
        config.logger.error("没有找到%s" % name)
        return 0


def keyLogCheck(testcase):
    """检查log文件大小
    不为0返回1
    否则返回0"""
    if isinstance(testcase, TestCase):
        list = testcase.id().split(".")
        list.pop(1)

        case_id = "_".join(list)
    else:
        case_id = testcase
    log_path = os.path.join(GV().LOG_ROOT, "%s_action.log" % case_id)
    if os.path.getsize(log_path) != 0:
        return 1
    else:
        return 0

def get_key_log(testcase):
    """检查log文件大小
    不为0返回1
    否则返回0"""
    if isinstance(testcase, TestCase):
        list = testcase.id().split(".")
        list.pop(1)

        case_id = "_".join(list)
    else:
        case_id = testcase
    log_path = os.path.join(GV().LOG_ROOT, "%s_action.log" % case_id)
    with open(log_path, "r") as file:
        content = file.readlines()
    return content


def keyLogCheckByText(keyword):
    """检查log文件大小
    不为0返回1
    否则返回0"""
    log_path = os.path.join(config.LOG_DIR, "action.log")
    with open(log_path, "w+") as file:
        import re

        if re.match(keyword, file.read()):
            return 1
        else:
            config.logger.error("日志中没有找到关键词%s" % keyword)
            return 0


def orientation():
    """横竖屏判断
    竖屏返回0
    横屏返回1"""
    d = Adb.get_device(GV().device_id, GV().AUTO_MODE)
    if d.orientation == "natural":
        return 0
    elif d.orientation == "right" or d.orientation == "left":
        return 1

