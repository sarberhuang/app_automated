Python3 + Appium + 安卓模拟器 实现APP自动化测试，并生成测试报告 示例项目


