import time
import unittest

from appium import webdriver

from common.Logger import Log
from pages.LoginPage import LoginPage
from pages.MyPage import MyPage



class MyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):

        desired_caps = {'platformName': 'Android',  # 平台名称
                        'platformVersion': '9',  # 系统版本号
                        'deviceName': '00395cd40207',  # 设备名称。如果是真机，在'设置->关于手机->设备名称'里查看
                        'appPackage': 'com.codemao.grow',  # apk的包名
                        'appActivity': '.ui.splash.SplashActivity',  # activity 名称
                        'noReset': "True"
                        }
        cls.driver = webdriver.Remote("http://127.0.0.1:4723/wd/hub", desired_caps)  # 连接Appium
        cls.driver.implicitly_wait(8)
        # 实例化对应页面的方法和对象
        cls.login_page = LoginPage(cls.driver)
        cls.my_page = MyPage(cls.driver)
        cls.log=Log()

        # cls.check_page=UICheck(cls.driver)

    # 测试开始前执行的方法
    def setUp(self):
        print('用例开始执行')

    def test_01(self, t=500, n=4):
        """进入首页测试"""
        time.sleep(8)

        self.my_page.click_my_button()
        time.sleep(1)
        self.my_page.find_element_bytext('联系客服')

        print('ok')


    # 测试结束后执行的方法
    def tearDown(self):
        print('123')

    # @classmethod
    # def tearDownClass(cls):
    #     cls.driver.quit()
